# time-tracker
Java (Maven) application for tracking time on the job

THis is an edit performing for Automatic poll option
